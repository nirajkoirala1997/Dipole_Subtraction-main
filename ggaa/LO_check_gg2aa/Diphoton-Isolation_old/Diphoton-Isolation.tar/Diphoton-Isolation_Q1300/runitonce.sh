make && ./cteq.x && make clean
