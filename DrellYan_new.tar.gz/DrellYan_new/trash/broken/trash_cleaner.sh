rm -f *.PK
rm -f *.Dipole
rm -f *.Virtual
rm -f *.Plus
rm -f *.LO
rm -f *.Delta
rm -f *.Regular
rm -f *.dat
